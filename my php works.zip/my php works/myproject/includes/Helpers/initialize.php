<?php
  //define the core path
  //define them as absolute paths to make sure that require_once works as expected

//DIRECTORY_SEPARATOR is a php pre-defined constant
// C\ for windows, / for Unix


defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);
 
//website root directory
defined('SITE_ROOT') ? null: define('SITE_ROOT', 'C:'.DS.'xampp'.DS.'htdocs'.DS.'musicroot');
//Admin panel directory
define('ADMIN_ROOT', SITE_ROOT.DS.'admin');
//PHP library directory
defined('LIB_PATH') ? null : define('LIB_PATH', SITE_ROOT.DS.'includes');
//uploads directory.
defined('UPLOAD_PATH') ? null : define('UPLOAD_PATH', SITE_ROOT.DS.'assets'.DS.'uploads');
//artist uploads path
defined('ARTIST_PATH') ? null : define('ARTIST_PATH', UPLOAD_PATH.DS.'artists');
//artist view path
defined('ARTIST_VIEW_PATH') ? null : define('ARTIST_VIEW_PATH', '..'.DS.'assets'.DS.'uploads'.DS.'artists');
//banner uploads path
defined('BANNER_PATH') ? null : define('BANNER_PATH', UPLOAD_PATH.DS.'banners');
//banner view path
defined('BANNER_VIEW_PATH') ? null : define('BANNER_VIEW_PATH', '..'.DS.'assets'.DS.'uploads'.DS.'banners');
//album uploads path
defined('ALBUM_PATH') ? null : define('ALBUM_PATH', UPLOAD_PATH.DS.'albums');
//album uploads path
defined('ALBUM_VIEW_PATH') ? null : define('ALBUM_VIEW_PATH', '..'.DS.'assets'.DS.'uploads'.DS.'albums'.DS.'album_images');
//album tracks path
defined('ALBUM_TRACK_PATH') ? null : define('ALBUM_TRACK_PATH', '..'.DS.'..'.DS.'assets'.DS.'uploads'.DS.'albums'.DS.'tracks');
//singles uploads path
defined('SINGLE_PATH') ? null : define('SINGLE_PATH', UPLOAD_PATH.DS.'singles');
//single view path
defined('SINGLE_TRACK_PATH') ? null : define('SINGLE_TRACK_PATH', '..'.DS.'..'.DS.'assets'.DS.'uploads'.DS.'singles'.DS.'tracks');
//instrumental uploads path
defined('INSTRUMENTAL_PATH') ? null : define('INSTRUMENTAL_PATH', UPLOAD_PATH.DS.'instrumentals');
//instrumental track uploads path
defined('INSTRUMENTAL_IMG_PATH') ? null : define('INSTRUMENTAL_IMG_PATH', INSTRUMENTAL_PATH.DS.'tracks');
//instrumental view path
defined('INSTRUMENTAL_TRACK_PATH') ? null : define('INSTRUMENTAL_TRACK_PATH', '..'.DS.'..'.DS.'assets'.DS.'uploads'.DS.'instrumentals'.DS.'tracks');
           
        //load config file first
        require_once(LIB_PATH.DS. 'Models'.DS.'config.php');
        
        //loading basic functions next so that everything after can use them
        require_once(LIB_PATH.DS.'Helpers'.DS.'functions.php');
        
        //load core objects
        require_once(LIB_PATH.DS.'Controllers'.DS.'session.php');
        require_once(LIB_PATH.DS.'Models'.DS.'database.php');
        require_once(LIB_PATH.DS.'Models'.DS.'database_object.php');
        require_once(LIB_PATH.DS.'Models'.DS.'pagination_model.php');
        require_once(LIB_PATH.DS.'Models'.DS.'createdb.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'pagination_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'album_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'album_tracks_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'photo_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'track_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'single_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'user_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'artist_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'client_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'banner_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'instrumental_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'comment_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'login_control.php');
        require_once(LIB_PATH.DS.'Controllers'.DS.'user_login_control.php');
        require_once(LIB_PATH.DS.'Helpers'.DS."PHPMailer".DS."PHPMailerAutoload.php");
        require_once(LIB_PATH.DS.'Helpers'.DS."PHPMailer".DS."mail_credentials.php");
        
        //load database(Model) related classes
        require_once(LIB_PATH.DS.'Models'.DS.'user.php');
        require_once(LIB_PATH.DS.'Models'.DS.'client.php');
        require_once(LIB_PATH.DS.'Models'.DS.'track.php');
        require_once(LIB_PATH.DS.'Models'.DS.'album.php');
        require_once(LIB_PATH.DS.'Models'.DS.'single.php');
        require_once(LIB_PATH.DS.'Models'.DS.'artist.php');
        require_once(LIB_PATH.DS.'Models'.DS.'banner.php');
        require_once(LIB_PATH.DS.'Models'.DS.'instrumental.php');
        require_once(LIB_PATH.DS.'Models'.DS.'album_tracks.php');
        require_once(LIB_PATH.DS.'Models'.DS.'photograph.php');
        require_once(LIB_PATH.DS.'Models'.DS.'comment.php');
    
   