<?php
//require_once(LIB_PATH.DS. 'Helpers'.DS.'initialize.php');
class FileProcessor{
    /************Image processing Parameters*************/
    //file names
    public $filename;
    //file names
    public $image_filename;
    //file names
    public $audio_name;
    //file names
    public $video_filename;

    //file types
    public $type;

    //file sizes
    public $size;

    //file temprorary paths
    private $file_temp_path;

    //file targetpath
    public $file_target_path;


    //file targetpath
    public $image_file_target_path;
    //file targetpath
    public $audio_file_target_path;
    //file targetpath
    public $video_file_target_path;



    public $audio_max_file_size = 20571520,  $image_max_file_size = 512000,  $video_max_file_size = 41143040; //expressed in bytes
    // 10240 = 10kb
    // 102400 = 100kb
    // 1048576 = 1MB
    // 10485760 = 10MB
    //20571520


    //file_upload_directory
    protected $upload_dir = "../../assets/uploads/albums/album_images";
    public  $errors = array();
    /************End of Image processing Parameters**********/

    protected $uploads_errors = array(
        //http://www.php.net/manual/en/features.file-upload.errors.php
        UPLOAD_ERR_OK         => "No error.",
        UPLOAD_ERR_INI_SIZE   => "Larger than upload max_file_size.",
        UPLOAD_ERR_FORM_SIZE  => "Larger than max_file_size.",
        UPLOAD_ERR_PARTIAL    => "partial UPLOAD.",
        UPLOAD_ERR_NO_FILE    => "No file.",
        UPLOAD_ERR_NO_TMP_DIR => "No temporary directory.",
        UPLOAD_ERR_CANT_WRITE => "cant write to disk.",
        UPLOAD_ERR_EXTENSION  => "file upload stopped by extension."
    );


    //constructor that accepts the image parameters parameters
    public function __construct() {

    }

    //function that check for fileType(file autoprocess function)
    public function processfile($file){
        $path = $file['name']; // file means your input type file name
        $ext = pathinfo($path, PATHINFO_EXTENSION);

        if ($ext=="jpg" OR $ext=="jpeg" OR $ext=="gif" OR $ext=="png") {
            // run image processor
            if($this->prepareImage($file) == false){
                return false;
            }

            return true;
            //add additional if statements to check for other files other fileTypes

        }


    }


    /*************Image processing methods*********************/

    //checks if its an image file before handing it over
    //to the prepareImage() function for processing.
    public function attachImage($file){
        $path = $file['name']; // file means your input type file name
        $ext = pathinfo($path, PATHINFO_EXTENSION);

        if ($ext=="jpg" OR $ext=="jpeg" OR $ext=="gif" OR $ext=="png") {
            // run image processor
            if ($this->prepareImage($file) == false) {
                return false;
            }
            return true;
        }
        $_POST['msg'] = "Invalid file, Please select a JPG, JPEG, GIF or PNG File";
        return false;
    }

    //function that verifies the image
    public function prepareImage($file){
        //check for file errors
        if($this->attach_file($file) == false){
            return false;
        }
        //checks for file size
        if ($this->fileSize($this->image_max_file_size, $file['size']) == false){
            return false;
        }
        //Set object attributes to the form parameters
        $this->parameterSetter($file);
        if ($this->processImage()==false){
            return false;
        }
        //and make it ready to be saved in the database
        return true;
    }

    //function process image for database
    public function processImage(){
        //Can't save if there are pre-existing errors
        if(!empty($this->errors)){ return FALSE; }

        //Cant save without filename
        if(empty($this->filename)  || empty($this->file_temp_path)){
            $this->errors[] = "File location not available";
            $message = "Some files location was not available";
            $_POST['msg'] = $message;
            return FALSE;
        }
        if($this->saveImage() == false){
            return false;
        }
        return true;
    }

    //function that saves the image in the target directory
    public function saveImage(){
        //Determine the target_paths
        $file_target_path  =  $this->imageDirectory().DS. $this->filename;

        //setting the target paths parameters
        $this->file_target_path  = $file_target_path;
        $this->image_file_target_path  = $file_target_path;
        $this->image_filename  =  $this->filename;

        if(isset($_POST['image'])){
            $file_target_path  =  $this->imageDirectory().DS.$_GET['filename'];
            if($this->removeFile($file_target_path) == false){
                $_POST['msg'] = "Failed, There was a problem with the old image!, Contact the system Administrator";
                return false;
            }
        }

        //moving the file to the target directory
        if ($this->moveSelectedFile() == false){
            return false;
        }


        return true;

    }

    //setting the image upload directory
    public function imageDirectory(){
        if(isset($_POST['single'])){
            return $this->upload_dir =  SINGLE_PATH.DS."single_images";
        }
        //for album images
        if(isset($_POST['album'])){
            return $this->upload_dir = ALBUM_PATH.DS."album_images";
        }
        //for artist
        if(isset($_POST['art'])){
            return $this->upload_dir = ARTIST_PATH;
        }
        //for artist
        if(isset($_POST['ban'])){
            return $this->upload_dir = BANNER_PATH;
        }

        return null;
    }


    /************End of image processing functions*************/



    /*************Audio processing methods*********************/

    //checks if its an mp3 file before handing it over
    //to the prepareAudio() function for processing.
    public function attachAudio($file){
        $path = $file['name']; // file means your input type file name
        $ext = pathinfo($path, PATHINFO_EXTENSION);

        if ($ext == "mp3") {
            // run audio processor
            if ($this->prepareAudio($file) == false) {
                return false;
            }
            return true;
        }
        $_POST['msg'] = "Invalid file, Please select an MP3 File";
        return false;
    }

    //function that verifies the image
    public function prepareAudio($file){
        //check for file errors
        if($this->attach_file($file) == false){
            return false;
        }
        //checks for file size
        if ($this->fileSize($this->audio_max_file_size, $file['size']) == false){
            return false;
        }
        //Set object attributes to the form parameters
        $this->parameterSetter($file);
        if ($this->processAudio()==false){
            return false;
        }
        //and make it ready to be saved in the database
        return true;
    }

    //function process image for database
    public function processAudio(){
        //Can't save if there are pre-existing errors
        if(!empty($this->errors)){ return FALSE; }

        //Cant save without filename
        if(empty($this->filename)  || empty($this->file_temp_path)){
            $this->errors[] = "File location not available";
            $message = "Some files location was not available";
            $_POST['msg'] = $message;
            return FALSE;
        }
        if($this->saveAudio() == false){
            return false;
        }
        return true;
    }

    //function that saves the image in the target directory
    public function saveAudio(){
        //Determine the target_paths
        $file_target_path  =  $this->audioDirectory().DS. $this->filename;

        //seting th target paths parameters
        $this->file_target_path  = $file_target_path;
        $this->audio_file_target_path  = $file_target_path;

        //moving the file to the target directory
        if ($this->moveSelectedFile() == false){
            return false;
        }
        return true;

    }

    //setting the audio upload directory
    public function audioDirectory(){
        if(isset($_POST['single'])){
            return $this->upload_dir =  SINGLE_PATH.DS."tracks";
        }
        //for album tracks
        if(isset($_POST['album'])){
            return $this->upload_dir = ALBUM_PATH.DS."tracks";
        }
        //for instrumental tracks
        if(isset($_POST['instrumental'])){
            return $this->upload_dir = INSTRUMENTAL_PATH.DS."tracks";
        }

        return null;
    }


    /************End of image processing functions*************/





    /****************General file processing methods**********/


    //for that delete images form the databse
    public function removeFile($path){
        if(file_exists($path)){
            $target_path = $path;
            return unlink($target_path) ? TRUE : FALSE;
        }
        return false;
        //Then remove the file
        //$this->filename = $filename;
    }

    //function that moves the file to the target firectory
    public function moveSelectedFile(){
        //Make sure a file doesn't already exist in the target location
        if(file_exists($this->file_target_path)) {
            $this->errors[] = "The file {$this->filename} already exist.";
            $_POST['msg']   = "The file {$this->filename} already exist.";
            return FALSE;
        }

        //Attempt to move the file
        if($this->moveFile($this->file_target_path)==false ){
            return false;

        }
        //final return statement if everything is successful
        return true;
    }

    //Pass in $_FILE(['uploaded_file']) as an argument
    public function attach_file($file)
    {
        //Perform error checking on the form parameters
        if ((!$file || empty($file) || !is_array($file))) {
            //error: nothing uploaded or wrong argument usage
            $this->errors[] = "No file was uploaded.";
            $message = "Some Image Files Were Missing";
            $_POST['msg'] = $message;
            return FALSE;
        } elseif ($file['error'] != 0) {
            //error report what php  says went wrong
            $this->errors[] = $this->uploads_errors[$file['error']];
            //second line that converst the errors to a message
            $message = $this->uploads_errors[$file['error']];
            $_POST['msg'] = $message;
            return FALSE;
        }
        return TRUE;

    }

    //function that checks file size
    public function fileSize($max_size, $size)
    {
        if ($size > $max_size) {
            //error: nothing uploaded or wrong argument usage
            $this->errors[] = "file larger than 20mb";
            $message = "file larger than " . $this->formatSizeUnits($max_size);
            $_POST['msg'] = $message;
            return FALSE;
        }
        return true;
    }

    //function that converts file size to readable format
    function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
    }

    //files parameter setter method
    public function parameterSetter($file){
        //setting the temporary paths
        $this->file_temp_path  = $file['tmp_name'];

        //setting the filenames
        $this->filename        = basename($file['name']);

        //setting the file types
        $this->type            = $file['type'];

        //setting the file size
        $this->size            = $file['size'];

    }

    //function that moves the files
    public function moveFile($file_target_path){
        if(move_uploaded_file($this->file_temp_path, $file_target_path)) {
            //Success
            return TRUE;
        }else{
            //File was not moved
            $this->errors[] = "The file upload failed, possibly due to "
                . "incorect permissions on the upload folder";
            $message = "The file upload failed, possibly due to "
                . "incorect permissions on the upload folder";
            $_POST['msg'] = $message;
            return FALSE;
        }
    }

    //function for displaying image size properly
    public function size_as_text(){
        if($this->size < 1024){
            return "{$this->size}";
        }elseif ($this->size < 1048576) {
            $size_kb = round($this->size/1024);
            return "{$size_kb} KB";
        } else {
            $size_mb = round($this->size/10485);
            return "{$size_mb} MB";
        }
    }

    /**************End of General file processing methods******/


}



