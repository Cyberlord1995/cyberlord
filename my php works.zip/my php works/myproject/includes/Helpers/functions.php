<?php
//function to remove 0 from dates and time
function strip_zeros_from_date($marked_string=""){
    //first remove the marked zeroes
    $no_zero = str_replace("*0", "", $marked_string);
    //then remove any remaining marks
    $cleaned_string = str_replace('*', '', $no_zero);
    return $cleaned_string;
}

//redirecting function
function redirect_to($location = NULL){
    if($location != NULL){
        header("Location: {$location}");
        exit;
    }
}

//function that displays messages
function output_message($message = ''){
    if(!empty($message)){
        return "<p class=\"message\">{$message}</p>";
    } else {
        return "";
    }
}

//autoload function for unknown links
function __autoload($class_name){
    $class_name = strtolower($class_name);
    $path  = LIB_PATH.DS."{$class_name}.php";
    if(file_exists($path)){
        require_once($path);
    } else {
        die("The file {$class_name}.php could not be found");
    }
}

//function that include layout template
//it is advisable to roll all layout tempalate intointo a class
function fetch_layout_template($template=""){
     $path = SITE_ROOT.DS.'public'.DS.'layouts'.DS.$template;
     return $path;
}

//it is advisable to roll all layout tempalate intointo a class
function include_layout_template($template=""){
    include(SITE_ROOT.DS.'public'.DS.'layouts'.DS.$template);
}
//it is advisable to roll all layout tempalate intointo a class
function include_admin_layout_template($template=""){
    include(ADMIN_ROOT.DS.'public'.DS.'layouts'.DS.$template);
}


//function that set page haeders and metas
function setPageHeader($template, $title, $meta){
    include(SITE_ROOT.DS.'public'.DS.'layouts'.DS.$template);
}

//function that sets page footer
function setPageFooter($file){
    $footer  = file_get_contents(fetch_layout_template($file));
    echo $footer;
}

//it is advisable to roll all layout tempalate intointo a class
function fetch_admin_layout_template($template=""){
    $path = ADMIN_ROOT.DS.'public'.DS.'layouts'.DS.$template;
    return $path;
}

//function that set page haeders and metas
function setAdminPageHeader($file, $title){
    $header  = file_get_contents(fetch_admin_layout_template($file));
    $header = preg_replace('/{title}/', $title, $header);
    echo $header;
}

//function that sets page footer
function setAdminPageFooter($file){
    $footer  = file_get_contents(fetch_admin_layout_template($file));
    echo $footer;
}




//function for log action
function log_action($action, $message=""){
    $logfile = SITE_ROOT.DS. 'logs' .DS. 'log.txt';
    $new = file_exists($logfile)?FALSE:TRUE;
    if($handle = fopen($logfile, 'a')){ //append mode
        $timestamp = strftime("%Y-%m-%d %H:%M:S", time());
        $content = "{$timestamp} | {$action}: {$message}\n";
        fwrite($handle, $content);
        fclose($handle);
        if($new){
            chmod($logfile, 0755);
        }
    } else {
        echo 'Could not open logfile for writting';
    }
}

function datetime_to_text($datetime=""){
    $unixdatetime = strtotime($datetime);
    return strftime("%B %d, %Y at %I:%M %p", $unixdatetime);
}