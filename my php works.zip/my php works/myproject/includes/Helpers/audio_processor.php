<?php
//require_once(LIB_PATH.DS. 'Helpers'.DS.'initialize.php');

class AudioProcessor{
    /************Image processing Parameters*************/
    //file names
    public $filename;

    //file types
    public $type;

    //file sizes
    public $size;

    //file temprorary paths
    private $file_temp_path;

    //file targetpath
    public $file_target_path;

    public $max_file_size = 20571520; //expressed in bytes
    // 10240 = 10kb
    // 102400 = 100kb
    // 1048576 = 1MB
    // 10485760 = 10MB
    //20571520


    //file_upload_directory
    protected $upload_dir = null;
    public  $errors = array();
    /************End of Image processing Parameters**********/

    protected $uploads_errors = array(
        //http://www.php.net/manual/en/features.file-upload.errors.php
        UPLOAD_ERR_OK         => "No error.",
        UPLOAD_ERR_INI_SIZE   => "Larger than upload max_file_size.",
        UPLOAD_ERR_FORM_SIZE  => "Larger than max_file_size.",
        UPLOAD_ERR_PARTIAL    => "partial UPLOAD.",
        UPLOAD_ERR_NO_FILE    => "No file.",
        UPLOAD_ERR_NO_TMP_DIR => "No temporary directory.",
        UPLOAD_ERR_CANT_WRITE => "cant write to disk.",
        UPLOAD_ERR_EXTENSION  => "file upload stopped by extension."
    );


    //constructor that accepts the image parameters parameters
    public function __construct() {

    }
    //function that takes the parameters
    public function imageSanitizer($file){
        $this->attach_file($file);
    }

    //setting the upload directory
    public function trackDirectory(){
        if(isset($_POST['single'])){
            return $this->upload_dir =  SINGLE_PATH.DS."tracks";
        }else{
            return $this->upload_dir = ALBUM_PATH.DS."tracks";
        }
    }

    //setting the imaege upload directory
    public function imageDirectory(){
        if(isset($_POST['single'])){
            return $this->upload_dir =  SINGLE_PATH.DS."single_images";
        }else{
            return $this->upload_dir = ALBUM_PATH.DS."tracks_images";
        }
    }

    //Pass in $_FILE(['uploaded_file']) as an argument
    public function attach_file($file){
        //Perform error checking on the form parameters
        if((!$file  || empty($file)   || !is_array($file))){
            //error: nothing uploaded or wrong argument usage
            $this->errors[] = "No file was uploaded.";
            $message = "Some Image Files Were Missing";
            $_POST['msg'] = $message;
            return FALSE;
        }elseif ($this->size > $this->max_file_size){
            //error: nothing uploaded or wrong argument usage
            $this->errors[] = "file larger than 20mb";
            $message = "file larger than 20mb";
            $_POST['msg'] = $message;
            return FALSE;
        }elseif ($file['error'] != 0) {
            //error report what php  says went wrong
            $this->errors[] = $this->uploads_errors[$file['error']];
            //second line that converst the errors to a message
            $message = $this->uploads_errors[$file['error']];
            $_POST['msg'] = $message;
            return FALSE;
        }else{
            //Set object attributes to the form parameters
            $this->parameterSetter($file);
            return TRUE;
            //and make it ready to be saved in the database
        }

    }

    //images parameter setter method
    public function parameterSetter($file){
        //setting the temporary paths
        $this->file_temp_path  = $file['tmp_name'];

        //setting the filenames
        $this->filename        = basename($file['name']);

        //setting the file types
        $this->type            = $file['type'];

        //setting the file size
        $this->size            = $file['size'];

    }

    //image processing function
    public function imageProcessor(){

        //Can't save if there are pre-existing errors
        if(!empty($this->errors)){ return FALSE; }

        //Cant save without filename
        if(empty($this->filename)  || empty($this->file_temp_path)){
            $this->errors[] = "File location not available";
            $message = "Some files location was not available";
            $_POST['msg'] = $message;
            return FALSE;
        }

        //Determine the target_paths
        $file_target_path  =  $this->trackDirectory().DS. $this->filename;


        //seting th target paths parameters
        $this->file_target_path  = $file_target_path;

        //Make sure a file doesn't already exist in the target location
        if(file_exists($this->file_target_path)) {
            $this->errors[] = "The file {$this->filename} already exist.";
            $_POST['msg']   = "The file {$this->filename} already exist.";
            return FALSE;
        }

        //make sure the file doesn't exist
        if($this->checkFile($file_target_path) == false){
            return false;
        }
        //Attempt to move the file
        if($this->moveFile($file_target_path)==false ){
            return false;

        }
        //final return statement if everything is successful
        return true;

    }

    //function that checks if the files exist
    public function checkFile($file_target_path){
        //Make sure a file doesn't already exist in the target location
        if(file_exists($file_target_path)) {
            $this->errors[] = "The file {$this->filename} already exist.";
            $message = "The file {$this->filename} already exist.";
            $_POST['msg'] = $message;
            return FALSE;
        }
        return true;
    }

    //function that moves the files
    public function moveFile($file_target_path){
        if(move_uploaded_file($this->file_temp_path, $file_target_path)) {
            //Success
            return TRUE;
        }else{
            //File was not moved
            $this->errors[] = "The file upload failed, possibly due to "
                . "incorect permissions on the upload folder";
            $message = "The file upload failed, possibly due to "
                . "incorect permissions on the upload folder";
            $_POST['msg'] = $message;
            return FALSE;
        }
    }


    function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
    }

    //image upload path
    public function image_path(){
        return $this->upload_dir.DS.$this->filename;
    }


}


