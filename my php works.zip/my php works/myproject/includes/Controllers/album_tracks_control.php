<?php
require_once(LIB_PATH.DS. 'Helpers'.DS.'initialize.php');
require_once(LIB_PATH.DS. 'Helpers'.DS.'image_processor.php');
//Class That controls the initialization

class AlbumTracksControl extends ImageProcessor {
    public $message;
    public $id;
    public $album;
    public $title;
    public $artist;
    public $released;
    public $downloads;
    public $category;
    public $length;
    public $size;
    public $file_path;


    //Pass in $_FILE(['uploaded_file']) as an argument
    //here the image is yo be processed

    //for that delete images from the database
    public function destroy(){
        //First remove the database entry
        if($this->deleteStaff()){//if database entry is deleted successfully
            //Then remove the file
            $target_path = SITE_ROOT.DS.'public'.DS.$this->image_path();
            return unlink($target_path) ? TRUE : FALSE;
        } else {
            //database delete failed
            return FALSE;
        }
    }

    //image upload path
    public function image_path(){
        return $this->upload_dir.DS.$this->filename;
    }

    //constructor that loads automatimally when the class in called
    public function __construct() {

        //checks if the form is posted
        if(isset($_POST['submit'])){

            $album       = $_POST['album'];
            $title       = $_POST['title'];
            $artist      = $_POST['artist'];
            $released    = $_POST['released'];
            $category    = $_POST['category'];
            $length      = $_POST['length'];
            $file        = $_FILES['file_path'];

            //validating user input
            if($this->validate_input($title, $artist, $released, $category, $length,
                    $size, $file) == true){
                //assigning the variable to the public vars
                $this->album            = $album;
                $this->title            = $title;
                $this->artist           = $artist;
                $this->release          = $released;
                $this->category         = $category;
                $this->length           = $length;
                $this->size             = $size;
                $this->file_path        = $this->file_target_path;

                //Set object attributes to the image parameters
                $this->addAlbum();

            }
        }

    }


    //Attribute Validation function
    public function validate_input($title, $artist, $released, $category, $length, $size, $file){
        //checks for empty fields
        if(empty($title) || empty($artist) || empty($released) || empty($download) || empty($category) || empty($length)
            || empty($size) || empty($file)){
            $message = "You left a blank field";
            $_POST['msg'] = $message;
            return false;
        }
        //checks for invalid characters
        if(!preg_match("/^[a-zA-Z0-9 ]*$/", $title)){
            $message = "Your Entries contains invalid characters";
            $this->message = $message;
            return false;
        }

        //attch file first
        if($this->attach_file($file) == false){
            return true;
        }

        //then image processor
        if($this->imageProcessor() == false){
            return false;
        }
        return true;
        /**
        //check if the password matches and checkbox is checked
        return $this->password_and_checkbox($password, $verify_password, $checkbox) == true ? true : false;
         **/
    }


    //password verification and checkbox
    public function password_and_checkbox($password, $verify_password, $checkbox){
        //check if the password matches
        if($password != $verify_password){
            $message = "Password doesn't match";
            $this->message = $message;
            return false;
        }
        //check if the checkbox is.. checked
        if(!empty($checkbox) && $checkbox == 'yes'){
            return true;
        }else{
            $message = "You need to agree to the terms of use";
            $this->message = $message;
            return false;
        }
    }

    //function that validates user email
    public function validate_staff($ID){
        $user = new Specialist();

        /**
        //checks for invalid email
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $message= "Invalid Email, Please verify the mail";
        $this->message = $message;
        return false;
        }
         * */
        //checks if the EMAIL EXIST
        if($user->check_staff($ID) == false){
            $message = "ID taken, Use Another ID";
            $this->message = $message;
            return false;
        }
        return true;
    }

    //function that validates user email
    public function validate_email($Email){
        $user = new Specialist();


        //checks for invalid email
        if(!filter_var($Email, FILTER_VALIDATE_EMAIL)){
            $message= "Invalid Email, Please verify the mail";
            $this->message = $message;
            return false;
        }

        //checks if the EMAIL EXIST
        if($user->check_user_email($Email) == false){
            $message = "Email Exists, Register Another Email";
            $this->message = $message;
            return false;
        }
        return true;
    }

    //update ward
    public function updateStaff($ID){

        $staff = new Specialist();
        $staff->DoctorID        =  $this->DoctorID;
        $staff->DoctorName      =  $this->DoctorName;
        $staff->FatherName       =  $this->FatherName;
        $staff->Address         =  $this->Address;
        $staff->ContactNo       =  $this->ContactNo;
        $staff->Email           =  $this->Email;
        $staff->Qualifications  =  $this->Qualifications;
        $staff->Specialization  =  $this->Specialization;
        $staff->Gender          =  $this->Gender;
        $staff->BloodGroup      =  $this->BloodGroup;
        $staff->DateOfJoining   =  $this->DateOfJoining;
        //$user->image_path = "uploads\images\oyin.jpg"; //default image.
        //$user->reg_date = strftime("%Y-%m-%d %H:%M:%S", time());
        //$user->password = $this->password;

        if($staff->update_by_doctor_ID($ID) == true ){
            $session = new Session();
            $_POST['msg'] = "Specialist Information Updated";
            $this->message = $_POST['msg'];
            redirect_to("specialist_list.php?msg=Specialist Information Updated");
        } else {
            $message = "Sorry! ): something went wrong";
            $this->message = $message;
            return false;
        }
    }

    //Registration method
    public function addAlbum(){

        $item = new Album();
        $item->album           =  $this->album;
        $item->title           =  $this->title;
        $item->artist          =  $this->artist;
        $item->released        =  $this->released;
        $item->downloads       =  $this->downloads;
        $item->category        =  $this->category;
        $item->length          =  $this->length;
        $item->size            =  $this->size;
        $item->file_path       =  $this->file_path;

        if($item->create() == true ){
            unset($this->temp_path);
            $session = new Session();
            $_POST['msg'] = "New Album Created, Proceed to add tracks!";
            //$session->message("User Created, Login to Activate your session");
        } else {
            $message = "Sorry! ): something went wrong";
            $this->message = $message;
            return false;
        }
    }

    //ward deleting method
    public function deleteItem(){
        //pic Must have an id
        if(isset($_GET['del_key'])){
            $items = new Kids();
            if($items && $items->destroyItem($_GET['del_key'])){
                $_GET['msg'] = "Product Deleted Succesfully";
                return true;
            } else {
                $_GET['msg'] = "Fail to Delete Product!";
                return false;
            }

        }


    }


}




