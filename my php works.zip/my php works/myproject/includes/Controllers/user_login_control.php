<?php
// put your code here
require_once(LIB_PATH.DS. 'Helpers'.DS.'initialize.php');
//class that handles login in and sessions
class UserLoginControl{
    // public $message = "Sign in to start your session";
    //function that runs automatically
    public function __construct() {
        //code that generally needs to run automatically stays within this block

    }

    //function that check if user is logged in
    public function is_Logged_in(){
        //checking if the user is logged in
        $session = new Session();
        if($session->is_logged_in()){
            redirect_to("index.php");
        }

    }


    // function that checks if the user is not logged in'
    public function is_not_Logged_in(){
        //checking if the user is logged in
        $session = new Session();
        if(!$session->is_logged_in()){
            return true;
        }
        return false;

    }
    // function that checks if the user is not logged in'
    public function is_not_Logged_in_within(){
        //checking if the user is logged in
        $session = new Session();
        if(!$session->is_logged_in()){
            return true;
        }
        return false;
    }



    //function loging user in
    public function loginUser($email="", $password=""){

        //Remember to give your form's submit tag a name="submit" attribute
        if(isset($_POST['submit'])){ //if form has been submitted
            $email     = trim($_POST['email']);
            $password  = trim($_POST['password']);

            //check the database to see if username and password exist
            $found_user = Client::verify_user($email, $password);
            if($found_user != false){
                $new_session = Client::authenticate($email);
                $session = new Session();
                $session->login($new_session);
                log_action('login', "{$found_user->username} logged in.");
                   $_POST['msg'] = "You are now logged in";
                   $_POST['succ'] = "succ";
            }
        }
        //end of the form processing

    }



    //logout function
    public function logoutUser(){
        $session = new Session();
        $session->logout();
        redirect_to("../../admin/login/index.php");
    }

}
