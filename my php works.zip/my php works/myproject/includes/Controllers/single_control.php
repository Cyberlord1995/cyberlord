<?php
require_once(LIB_PATH.DS. 'Helpers'.DS.'initialize.php');
require_once(LIB_PATH.DS. 'Helpers'.DS.'file_processor.php');
//Class That controls the initialization

class SingleControl extends FileProcessor {
    public $message;
    public $id;
    public $title;
    public $artist;
    public $released;
    public $downloads;
    public $genre;
    public $size;
    public $category;
    public $file_path;
    public $filename;
    public $image_path;
    public $image_name;

    //Pass in $_FILE(['uploaded_file']) as an argument
    //here the image is yo be processed

    //for that delete images from the database
    public function destroy(){
        //First remove the database entry
        if($this->deleteStaff()){//if database entry is deleted successfully
            //Then remove the file
            $target_path = SITE_ROOT.DS.'public'.DS.$this->image_path();
            return unlink($target_path) ? TRUE : FALSE;
        } else {
            //database delete failed
            return FALSE;
        }
    }

    //image upload path
    public function audio_path(){
        return $this->upload_dir.DS.$this->filename;
    }

    //constructor that loads automatimally when the class in called
    public function __construct() {

        //checks if the form is posted
        if(isset($_POST['submit'])){
            $_POST['single'] = true;
            $title       = $_POST['title'];
            $artist      = $_POST['artist'];
            $released    = $_POST['released'];
            $genre       = $_POST['genre'];
            $category    = $_POST['category'];
            $file        = $_FILES['file'];
            $size        = $file['size'];
            $filename    = $file['name'];
//            $image       = $_FILES['image'];
//            $image_name  = $image['name'];


            //validating user input
            if($this->validate_input($title, $artist, $released, $genre, $category, $file) == true){
                //assigning the variable to the public vars
                $this->title            = $title;
                $this->artist           = $artist;
                $this->released         = $released;
                $this->category         = $category;
                $this->genre            = $genre;
                $this->file_path        = $this->file_target_path;
                $this->size             = $size;
                $this->filename         = $filename;
//                $this->image_name       = $image_name;
//                $this->image_path       = $this->file_target_path;
                //Set object attributes to the image parameters
                $this->addAlbum();

            }
        }

    }


    //Attribute Validation function
    public function validate_input($title, $artist, $released, $genre, $category, $file){
        //checks for empty fields
        if(empty($title) || empty($artist) || empty($genre) || empty($released) || empty($category) || empty($file)){
            $message = "You left a blank field";
            $_POST['msg'] = $message;
            return false;
        }
        //checks for invalid characters
        if(!preg_match("/^[a-zA-Z0-9 ]*$/", $title)){
            $message = "Your Entries contains invalid characters";
            $this->message = $message;
            return false;
        }


        //checks if the track exists
        $album = new Single();
        if($album::check_album($title) == false){
            $message = "Single exists, please choose another title";
            $_POST['msg'] = $message;
            return false;
        }

        //attach prompt image file first
//        if($this->prepareImage($file)==false){
//            return false;
//        }

        //then process the audio file
        if($this->attachAudio($file)==false){
            return false;
        }

        return true;

    }

    //checks if the album exists
    public function checkAlbum($title){
        $album = new Album();
        if($album::check_album($title) == false){
            $message = "Album exists, please choose another title";
            $_POST['msg'] = $message;
            return false;
        }
        return false;
    }

    //function that validates user email
    public function validate_staff($ID){
        $user = new Specialist();

        /**
        //checks for invalid email
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $message= "Invalid Email, Please verify the mail";
        $this->message = $message;
        return false;
        }
         * */
        //checks if the EMAIL EXIST
        if($user->check_staff($ID) == false){
            $message = "ID taken, Use Another ID";
            $this->message = $message;
            return false;
        }
        return true;
    }

    //function that validates user email
    public function validate_email($Email){
        $user = new Specialist();


        //checks for invalid email
        if(!filter_var($Email, FILTER_VALIDATE_EMAIL)){
            $message= "Invalid Email, Please verify the mail";
            $this->message = $message;
            return false;
        }

        //checks if the EMAIL EXIST
        if($user->check_user_email($Email) == false){
            $message = "Email Exists, Register Another Email";
            $this->message = $message;
            return false;
        }
        return true;
    }

    //for that delete audio file from the databse
    public function removeSelectedFile($filename){
        //Then remove the file
        $this->filename = $filename;
        $target_path = SINGLE_TRACK_PATH.DS.$filename;
        return unlink($target_path) ? TRUE : FALSE;

    }



    //Registration method
    public function addAlbum(){

        $track = new Single();
        $track->title           =  $this->title;
        $track->artist          =  $this->artist;
        $track->released        =  $this->released;
        $track->genre           =  $this->genre;
        $track->size            =  $this->formatSizeUnits($this->size);
        $track->category        =  $this->category;
        $track->file_path       =  $this->file_path;
        $track->filename        =  $this->filename;

        if($track->create() == true ){
            unset($this->temp_path);
            $session = new Session();
            $_POST['msg'] = "New Single added";
            //$session->message("User Created, Login to Activate your session");
        } else {
            $message = "Sorry! ): something went wrong";
            $this->message = $message;
            return false;
        }
    }


    //ward deleting method
    public function destroyTrack(){
        //pic Must have an id
        if(isset($_GET['del_key'])){
            $albums = new Single();
            if($albums && $albums->deleteAlbum($_GET['key'])){
                if($this->removeSelectedFile($_GET['filename'])==true){
                    $_POST['msg'] = "Track Deleted Succesfully";
                    $_POST['succ'] = "succ";
                    return true;
                }
                $_POST['msg'] = "Fail to Delete Track files! ";
                return false;
            } else {
                $_POST['msg'] = "Fail to Delete Track!";
                return false;
            }

        }



    }


}




