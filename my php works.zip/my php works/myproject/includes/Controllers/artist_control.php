<?php
require_once(LIB_PATH.DS. 'Helpers'.DS.'initialize.php');
require_once(LIB_PATH.DS. 'Helpers'.DS.'file_processor.php');
//Class That controls the initialization

class ArtistControl extends FileProcessor {
    public $message;
    public $id;
    public $fullname;
    public $age;
    public $gender;
    public $genre;
    public $category;
    public $file_path;
    public $filename;

    //for that delete images from the database
    public function destroy(){
        //First remove the database entry
        if($this->deleteStaff()){//if database entry is deleted successfully
            //Then remove the file
            $target_path = SITE_ROOT.DS.'public'.DS.$this->image_path();
            return unlink($target_path) ? TRUE : FALSE;
        } else {
            //database delete failed
            return FALSE;
        }
    }

    //constructor that loads automatimally when the class in called
    public function __construct() {
        //checks if the form is posted
        if(isset($_POST['submit'])){
            //New Artist registration method
            $this->newArtist();
        }elseif(isset($_POST['update'])){
            //Admin update method.
            $this->udpdate();
        }elseif(isset($_POST['image'])){
            //Admin update method.
            $this->changeImage();
        }

    }





    public function newArtist(){
        $_POST['art'] = true;
        $fullname    = $_POST['name'];
        $age         = $_POST['age'];
        $genre       = $_POST['genre'];
        $gender      = $_POST['gender'];
        $category    = $_POST['category'];
        $file        = $_FILES['file'];
        $filename    = $file['name'];
//            $image       = $_FILES['image'];
//            $image_name  = $image['name'];

        //validating user input
        if($this->validate_input($fullname, $age, $gender, $genre, $category, $file) == true){
            //assigning the variable to the public vars
            $this->fullname         = $fullname;
            $this->age              = $age;
            $this->gender           = $gender;
            $this->category         = $category;
            $this->genre            = $genre;
            $this->file_path        = $this->file_target_path;
            $this->filename         = $filename;
//                $this->image_name       = $image_name;
//                $this->image_path       = $this->file_target_path;
            //Set object attributes to the image parameters
            $this->addArtist();

        }
    }

    //function that update user all attributes
    public function udpdate(){

        $_POST['artist'] = true;
        $fullname    = $_POST['name'];
        $age         = $_POST['age'];
        $genre       = $_POST['genre'];
        $gender       = $_POST['gender'];
        $category    = $_POST['category'];
        $file_path   = $_POST['file_path'];
        $filename    = $_POST['filename'];
//            $image       = $_FILES['image'];
//            $image_name  = $image['name'];

        //validating user input
        if($this->validate_input($fullname, $age, $gender, $genre, $category, $filename) == true){
            //assigning the variable to the public vars
            $this->fullname         = $fullname;
            $this->age              = $age;
            $this->gender           = $gender;
            $this->category         = $category;
            $this->genre            = $genre;
            $this->file_path        = $file_path;
            $this->filename         = $filename;
            $this->updateArtist();
            }

    }

    //function that update user all attributes
    public function changeImage(){

        $_POST['artist'] = true;
        $file        = $_FILES['file'];
        $filename    = $file['name'];;
//            $image       = $_FILES['image'];
//            $image_name  = $image['name'];
        if($this->attachImage($file)==false){
            return false;
        }
        $this->file_path        = $this->file_target_path;
        $this->filename         = $filename;
        $this->updateImage();


    }


    //Update user method
    public function updateArtist(){

        $track = new Artist();
        $track->fullname        =  $this->fullname;
        $track->age             =  $this->age;
        $track->gender          =  $this->gender;
        $track->genre           =  $this->genre;
        $track->category        =  $this->category;
        $track->file_path       =  $this->file_path;
        $track->filename        =  $this->filename;
        $track->id = $_GET['key'];
        if($track->update()  == true ){
            $_POST['msg'] = "Artist Information Updated!";
            $_POST['succ'] = 'set';
        } else {
            $message = "Sorry! ): something went wrong";
            $_POST['msg'] = $message;
            return false;
        }
    }

    //
    //Update user method
    public function updateImage(){

        $track = new Artist();
        $track->file_path       =  $this->file_path;
        $track->filename        =  $this->filename;
        $track->id = $_GET['key'];
        if($track->updateImage()  == true ){
            $_POST['msg'] = "Artist Information Updated!";
            $_POST['succ'] = 'set';
        } else {
            $message = "Sorry! ): something went wrong";
            $_POST['msg'] = $message;
            return false;
        }
    }

    //Attribute Validation function
    public function validate_input($fullname, $age, $gender,  $genre, $category, $file){
        //checks for empty fields
        if(empty($fullname) || empty($age)  || empty($gender) || empty($genre) || empty($category) || empty($file)){
            $message = "You left a blank field";
            $_POST['msg'] = $message;
            return false;
        }
        //checks for invalid characters
        if(!preg_match("/^[a-zA-Z0-9 ]*$/", $fullname)){
            $message = "Your Entries contains invalid characters";
            $this->message = $message;
            return false;
        }


        //validates email
        if(isset($_POST['submit'])) {
            //checks if the track exists
            $album = new Artist();
            if ($album::check_artist($fullname) == false) {
                $message = "Artist exists, please choose another Artist";
                $_POST['msg'] = $message;
                return false;
            }
            //then process the image file
            if($this->attachImage($file)==false){
                return false;
            }
        }


        return true;

    }

    //checks if the album exists
    public function checkAlbum($title){
        $album = new Album();
        if($album::check_album($title) == false){
            $message = "Album exists, please choose another title";
            $_POST['msg'] = $message;
            return false;
        }
        return false;
    }

    //function that validates user email
    public function validate_staff($ID){
        $user = new Specialist();

        /**
        //checks for invalid email
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $message= "Invalid Email, Please verify the mail";
        $this->message = $message;
        return false;
        }
         * */
        //checks if the EMAIL EXIST
        if($user->check_staff($ID) == false){
            $message = "ID taken, Use Another ID";
            $this->message = $message;
            return false;
        }
        return true;
    }

    //function that validates user email
    public function validate_email($Email){
        $user = new Specialist();


        //checks for invalid email
        if(!filter_var($Email, FILTER_VALIDATE_EMAIL)){
            $message= "Invalid Email, Please verify the mail";
            $this->message = $message;
            return false;
        }

        //checks if the EMAIL EXIST
        if($user->check_user_email($Email) == false){
            $message = "Email Exists, Register Another Email";
            $this->message = $message;
            return false;
        }
        return true;
    }

    //for that delete images form the databse
    public function removeSelectedFile($filename){
        //Then remove the file
        $this->filename = $filename;
        $target_path = ARTIST_PATH.DS.$filename;
        return unlink($target_path) ? TRUE : FALSE;

    }



    //Registration method
    public function addArtist(){

        $track = new Artist();
        $track->fullname        =  $this->fullname;
        $track->age             =  $this->age;
        $track->gender          =  $this->gender;
        $track->genre           =  $this->genre;
        $track->category        =  $this->category;
        $track->file_path       =  $this->file_path;
        $track->filename        =  $this->filename;

        if($track->create() == true ){
            unset($this->temp_path);
            $session = new Session();
            $_POST['msg'] = "New Artist added";
            //$session->message("User Created, Login to Activate your session");
        } else {
            $message = "Sorry! ): something went wrong";
            $this->message = $message;
            return false;
        }
    }


    //ward deleting method
    public function destroyArtist(){
        //pic Must have an id
        if(isset($_GET['del_key'])){
            $albums = new Artist();
            if($albums && $albums->deleteAlbum($_GET['key'])){
                if($this->removeSelectedFile($_GET['filename'])==true){
                    $_POST['msg'] = "Artist Deleted Succesfully";
                    $_POST['succ'] = "succ";
                    return true;
                }
                $_POST['msg'] = "Fail to Delete Track files! ";
                return false;
            } else {
                $_POST['msg'] = "Fail to Delete Track!";
                return false;
            }

        }


    }


}




