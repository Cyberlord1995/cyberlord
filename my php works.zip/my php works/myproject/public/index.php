<!Doctype html>
<html>
<head>
    <title>CyberLord</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<h1>Everything Starts with An Idea</h1>
<p>Anything you imagine can be built into reality</p>



</body>
</html>
