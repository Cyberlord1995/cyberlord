<?php
class Photograph extends DatabaseObject{
     //our database columns are attributes individually
    //database column variables
    protected static $table_name = "photographs";
    protected static $db_fields = array('id', 'filename', 'type', 'size',
    'caption'
    );
    
    public $id;
    public $filename;
    public $type;
    public $size;
    public $caption;
    
    private $temp_path;
    protected $upload_dir = "images";
    public $errors = array();
    
    protected $uploads_errors = array(
  //http://www.php.net/manual/en/features.file-upload.errors.php   
        UPLOAD_ERR_OK         => "No error.",
        UPLOAD_ERR_INI_SIZE   => "Larger than upload max_file_size.",
        UPLOAD_ERR_FORM_SIZE  => "Larger than max_file_size.",
        UPLOAD_ERR_PARTIAL    => "partial UPLOAD.",        
        UPLOAD_ERR_NO_FILE    => "No file.",        
        UPLOAD_ERR_NO_TMP_DIR => "No temporary directory.",        
        UPLOAD_ERR_CANT_WRITE => "cant write to disk.", 
        UPLOAD_ERR_EXTENSION  => "file upload stopped by extension."    
);

    //Pass in $_FILE(['uploaded_file']) as an argument
    public function attach_file($file){
        //Perform error checking on the form parameters
        if(!$file || empty($file) || !is_array($file)){
            //error: nothing uplosded or wrong argument usage
            $this->errors[] = "No file was uploaded.";
            return FALSE;
        }elseif ($file['error'] != 0) {
            //error report what php  says went wrong
            $this->errors[] = $this->uploads_errors[$file['error']];
            return FALSE;
        }else{
        //Set object attributes to the form parameters
        $this->temp_path  = $file['tmp_name'];
        $this->filename   = basename($file['name']);
        $this->type       = $file['type'];
        $this->size       = $file['size'];
        return TRUE;
        //and make it ready to be saved in the database 
        }

    }
    
    //custom image save method
    public function save(){
        //A new record won't have an id yet
        //update if there is an existing record
        if(isset($this->id)){
            //Really just to update the caption
            $this->update();
        } else {
            //Make sure there no errors
            
            //Can't save if there are pre-existing errors
            if(!empty($this->errors)){ return FALSE; }
            
            //Make sure the caption is not too long
            if (strlen($this->caption) > 255){
                $this->errors[] = "The caption is too long";
                return FALSE;
            }
            
            //Cant save without filename
            if(empty($this->filename) || empty($this->temp_path)){
                $this->errors[] = "The file location was not available";
                return FALSE;
            }
            
            //Determine the target_path
            $target_path = SITE_ROOT .DS. 'public' .DS. $this->upload_dir .DS. $this->filename;
            
            //Make sure a file doesn't already exist in the target location
            if(file_exists($target_path)) {
                $this->errors[] = "The file {$this->filename} already exist.";
                return FALSE;
            }
            //Attempt to move the file
            if(move_uploaded_file($this->temp_path, $target_path)){
                //Success
                // Save a corresponding entry to the database
                if($this->create()){
                    //We are done with temp_path, the file isn't there anymore
                    unset($this->temp_path);
                    return TRUE;
                }
            }else{
                //File was not moved
                $this->errors[] = "The file upload failed, possibly due to "
                        . "incorect permissions on the upload folder";
                return FALSE;
            }
        }
    }
    
     //for that delete images form the databse
     public function destroy(){
         //First remove the database entry
         if($this->delete()){//if database entry is deleted successfully
            //Then remove the file 
             $target_path = SITE_ROOT.DS.'public'.DS.$this->image_path();
             return unlink($target_path) ? TRUE : FALSE;
         } else {
             //database delete failed
             return FALSE;
         }
     }

    //image upload path
    public function image_path(){
        return $this->upload_dir.DS.$this->filename;
    }
    
    //function for displaying image size properly
    public function size_as_text(){
        if($this->size < 1024){
            return "{$this->size}";
        }elseif ($this->size < 1048576) {
            $size_kb = round($this->size/1024);
            return "{$size_kb} KB";
        } else {
            $size_mb = round($this->size/10485);
            return "{$size_mb} MB";
        }
    }

    //comments retrieval method
    public function comments(){
        return Comment::find_comments_on($this->id);
    }
     
    
    /* common Database Methods */
    //function that get all results from sql query
    public static function find_all(){
        global $database;
        $result_set = self::find_by_sql("SELECT * FROM ". self::$table_name);
        return $result_set;
    }
    
     //function that get all results by id
    public static function find_by_id($id = 0){
        global $database;
        $result_array = self::find_by_sql("SELECT * FROM " .self::$table_name.  " WHERE id=".$database->escape_value($id). " LIMIT 1");
        return !empty($result_array) ? array_shift($result_array) : FALSE;
    }
    
    //function that get by sql
    public static function find_by_sql($sql=""){
        global $database;
        $result_set = $database->query($sql);
        $object_array = array();
        while ($row =  $database->fetch_array($result_set)){
            $object_array[] = self::instantiate($row);
        }
        return $object_array;
    }
    
    //function that counts records in a table
    public static function count_all(){
        global $database;
        $sql = "SELECT COUNT(*) FROM " .self::$table_name;
        $result_set = $database->query($sql);
        $row = $database->fetch_array($result_set);
        return array_shift($row);
    }

    //function that instantiate the database records
    private static function instantiate($record){
        $object = new self;
       // $object->id = $record['id'];
       // $object->username   = $record['username'];
       // $object->password   = $record['password'];
       // $object->first_name = $record['first_name'];
       // $object->last_name  = $record['last_name'];
     
        //more dynamic, short form appraoch
        foreach ($record as $attribute=>$value){
            if($object->has_attribute($attribute)){
                $object->$attribute = $value;
            }
        }
        return $object;
    } 
      
    //function to check the existence of an array key
    private function has_attribute($attribute){
        //get object vars returns an associateive array with all attribute
        //(incl. private ones!) as the key their current values as the value
        $object_vars = get_object_vars($this);
        //just want to know if the value exists
        //will return true or false
        return array_key_exists($attribute, $object_vars);
    }
    
    //attrubutes fuction that returns the key of table
    protected function attributes(){
        //return an array of attributes keys and their values
       $attributes = array();
       foreach(self::$db_fields as $field) {
           if(property_exists($this, $field)){
               $attributes[$field] = $this->$field;
           }
       }
       return $attributes;
    }
    
    //sanitised attributes with escape value
    protected function sanitized_attributes() {
        global $database;
        $clean_attributes = array();
        //sanitize the values befor submitting
        //Note: does not alter the actual value of eack attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $database->escape_value($value);
        }
        return $clean_attributes;
    }
    
    /** Replaced with a custom save method for photograph class **/
    //Function that for the existence of the record
    //if not exist then it creates it
    //public function save(){
     //A new function won't have an id yet
     //return isset($this->id)? $this->update() : $this->create();
    //}

    //The craete function
   public function create(){
       global $database;
       //Don't forget your SQL syntax and good habits
       // - INSERT INTO table (key, key) VALUES('value', 'value')
       // - single - quotes around all values
       // - escape all values to prevent SQL injection
      $attributes = $this->sanitized_attributes();
       $sql = "INSERT INTO " .self::$table_name. " (";
       $sql .= join(", ", array_keys($attributes));
       $sql .= ") VALUES ('";
       $sql .= join("', '", array_values($attributes));
       $sql .= "')";
       if($database->query($sql)){
       $this->id = $database->insert_id();
           return TRUE;
       } else {
           return FALSE;
       }
   }
   
   //the update function
   public function update(){
       global $database;
       //Don't forget your SQL syntax and good habits
       // - UPDATE table SET key='value', key='value' WHERE condition 
       // - single - quotes around all values
       // - escape all values to prevent SQL injection
       $attributes = $this->sanitized_attributes();
       $attributes_pairs = array();
       foreach($attributes as $key => $value){
           $attributes_pairs[] = "{$key}='{$value}'";
       }
       
       $sql = "UPDATE" .self::$table_name." SET ";
       $sql .= join(", ", $attributes_pairs);
       $sql .= " WHERE id=". $database->escape_value($this->id);
       $database->query($sql);
       return($database->affected_rows() == 1)? TRUE : FALSE;
   }
   
   //the delete function
   public function delete(){
        global $database;
       //Don't forget your SQL syntax and good habits
       // - DELETE FROM table WHERE condition LIMIT 1 
       // - single - quotes around all values
       // - escape all values to prevent SQL injection
        $sql = "DELETE FROM ". self::$table_name;
        $sql .= " WHERE id=". $database->escape_value($this->id);
        $sql .= " LIMIT 1";
        $database->query($sql);
        return($database->affected_rows() == 1)? TRUE : FALSE;
        
    }
    
    
}

