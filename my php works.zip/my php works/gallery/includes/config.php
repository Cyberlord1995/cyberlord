<?php
//Constants for database connection
defined('DB_SERVER')? null :define("DB_SERVER", "localhost");
defined('DB_USER')? null :define("DB_USER", "cyberlord");
defined('DB_PASS')? null :define("DB_PASS", "passcode1995");
defined('DB_NAME')? null :define("DB_NAME", "photo_GALLERY");
