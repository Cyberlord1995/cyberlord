<?php
/*
 * if it's going to need the database, then it's
 * probably smart to require it first
 */
require_once(LIB_PATH.DS. 'database.php');

class DatabaseObject{
    
}