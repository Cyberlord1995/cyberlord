<?php
//My Mail Username and password
define('EMAIL', 'a.ycelebrities@gmail.com');
define('PASS', 'sinmiloluwa');

