<?php
//In an application this could be moved to a config file
$uploads_errors = array(
  //http://www.php.net/manual/en/features.file-upload.errors.php
    
UPLOAD_ERR_OK         => "No error.",
UPLOAD_ERR_INI_SIZE   => "Larger than upload max_file_size.",
UPLOAD_ERR_FORM_SIZE  => "Larger than max_file_size.",
UPLOAD_ERR_PARTIAL    => "partial UPLOAD.",        
UPLOAD_ERR_NO_FILE    => "No file.",        
UPLOAD_ERR_NO_TMP_DIR => "No temporary directory.",        
UPLOAD_ERR_CANT_WRITE => "cant write to disk.", 
UPLOAD_ERR_EXTENSION  => "file upload stopped by extension."    
);

if(isset($_POST['submit'])){
    //process the form data
    $tmp_file = $_FILES['file_upload']['tmp_name'];
    $target_file = basename($_FILES['file_upload']['name']);
    $uploads_dir = "uploads";
    
    //You will probably want to first use file_exist() to make sure
    //there isn't already a file by the same name 
   
    //move_uploaded_file will return false if $tmp_file is not valid upload file
    //or if it cannot be moved for any reason
    
    if(move_uploaded_file($tmp_file, $uploads_dir."/".$target_file)){
        $message = "File uploaded succssfully";
    } else {
        $error = $_FILES['file_upload']['error'];
        $message = $uploads_errors[$error];
    }
}   



?> 



<!DOCTYPE html>
<?php
//The maximum file size (in bytes) must be declared before the file input field
// and cant be larger than the settingsfor max_upload_filesize in php.ini
//
//This form value can be manipulated.You should stilluse it but you rely
//on upload_max_filesize as the absolute limit
//
//Think of it as a polite declaration: "Hey php, here come a file less than x..."
//PHP will stop and complain once X is exceeded
//
//1 megabyte is actually 1,048,576 bytes.
//You can round it unless the precision matters
 
?>
<?php
//for passing messages
if(!empty($message)){echo "<p>{$message}</p>";}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Upload</title>
    </head>
    <body>
        <form action="upload.php" enctype="multipart/form-data" method="post">
            <input type="hidden" name="MAX_FILE_SIZE" value="100000">
            <input type="file" name="file_upload" />
            <input type="submit" name="submit" value="Upload">
        </form>
    </body>
</html>
<?php
//file upload error
//UPLOAD_ERR_OK = 0 = No error
//UPLOAD_ERR_INI_SIZE = 1 = Larger than upload max_file_size
//UPLOAD_ERR_FORM_SIZE = 2 = Larger than max_file_size
//UPLOAD_ERR_PARTIAL = 3 = partial UPLOAD        
//UPLOAD_ERR_NO_FILE = 4 = No file        
//UPLOAD_ERR_NO_TMP_DIR = 6 = No temporary directory        
//UPLOAD_ERR_CANT_WRITE = 7 = cant write to disk 
//UPLOAD_ERR_EXTENSION = 8 = file upload stopped by extension        
        ?>