-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2020 at 01:17 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `photo_gallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `photograph_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `author` varchar(255) NOT NULL,
  `body` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `photograph_id`, `created`, `author`, `body`) VALUES
(4, 4, '2019-05-22 02:34:53', 'kkkkk', 'bbbbbb'),
(5, 4, '2019-05-22 02:36:11', 'Good guys', 'at bible college'),
(6, 4, '2019-05-22 02:39:08', 'Good guys', 'at bible college'),
(7, 4, '2019-05-22 02:41:36', 'aasd', 'asdda'),
(8, 4, '2019-05-24 21:42:13', 'just testing my code', 'debugging mode activated'),
(9, 4, '2019-05-24 21:43:45', 'another test mail', 'thei is ed commment'),
(10, 5, '2019-09-18 23:01:14', 'Joshua', 'my comment');

-- --------------------------------------------------------

--
-- Table structure for table `photographs`
--

CREATE TABLE `photographs` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `size` varchar(12) NOT NULL,
  `caption` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photographs`
--

INSERT INTO `photographs` (`id`, `filename`, `type`, `size`, `caption`) VALUES
(6, 'joshua (3).jpg', 'image/jpeg', '98344', 'jossy'),
(8, '99u-wallpapers-peter-2560x1440.gif', 'image/gif', '26123', 'code'),
(9, '14470365_346664425669273_1828362428617087607_n.jpg', 'image/jpeg', '102708', 'BROTHER AND SIS'),
(11, '26167927_1944131139185498_1031747644190094781_n.jpg', 'image/jpeg', '108094', 'big sis'),
(12, '37048481_674455032890209_8393869721484656640_n.jpg', 'image/jpeg', '39480', 'big sis'),
(14, '0083394_edimax-2-x-2-ac-single-band-outdoor-poe-access-point_600.jpeg', 'image/jpeg', '12635', 'aaaa'),
(15, '143273-popular-computer-science-wallpaper-1920x1080.jpg', 'image/jpeg', '357668', 'background'),
(16, '6184.jpg', 'image/jpeg', '151928', 'birthname'),
(17, '12.jpg', 'image/jpeg', '44983', 'comp lab'),
(18, '004d507ca75c354bf6b67f95afe2acda.jpg', 'image/jpeg', '101138', 'sdq');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `firstname`, `lastname`) VALUES
(1, 'cyberlord', 'passcode', 'joshua', 'stephen');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photographs`
--
ALTER TABLE `photographs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `photographs`
--
ALTER TABLE `photographs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
