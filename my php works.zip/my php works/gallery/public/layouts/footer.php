 <div id="footer">Copyright <?php echo date("Y", time());?> Cyberlord</div>
    </body>
</html>
<?php if(isset($database)) {$database->close_connection();} ?>