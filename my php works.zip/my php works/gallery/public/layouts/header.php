<html>
    <head>
        <meta charset="UTF-8">
        <title>Photo Gallery</title>
        <link href="stylesheets/main.css" media="all" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div id="header">
            <h1>Photo Gallery</h1>
        </div>
        <div id="main">
