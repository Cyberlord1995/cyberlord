  <?php
require_once("../../includes/initialize.php");


//to check if the user is logged in
if(!$session->is_logged_in()){
    redirect_to("login.php");
}
?>
<?php include_layout_template("admin_header.php"); ?>

         <?php
         $user = new User();
         $user->username = "johnsmith";
         $user->password = "password";
         $user->firstname = "john";
         $user->lastname = "smith";
         $user->create();
          ?>
<?php include_layout_template("admin_footer.php"); ?>
