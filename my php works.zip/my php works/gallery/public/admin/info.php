<?php

echo phpinfo();
