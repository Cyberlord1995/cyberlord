<?php require_once '../../includes/initialize.php'; ?> 
<?php if(!$session->is_logged_in()) {
     redirect_to("login.php");
}?>

<?php
$logfile = SITE_ROOT.DS.'logs'.DS.'log.txt';

if($_GET['clear'] == 'true'){
    file_put_contents($logfile, '');
    //Add the first log entry
    log_action('logs Cleared', "By User ID {$session->user_id}");
    //redirect  to this ame page so that the url wont 
    //have clear=true anymore
    redirect_to('logfile.php');
}
?>

<?php include_layout_template('admin_header.php'); ?>

<a href="index.php">&laquo; Back</a><br/>
<br/>
<h2>log File</h2>

<p><a href="logfile.php?clear=true">Clear log file</a></p>

<?php
if(file_exists($logfile) && is_readable($logfile) &&
        $handle = fopen($logfile, 'r')){ //read
        echo "<ul class=\"log-entries\">";
        while (!feof($handle)){//foef means is used to locate the end of a file
            $entry = fgets($handle); //gets entries line by line
            if(trim($entry) != ""){
                echo "<li>{$entry}</li>";
            }
            
        }
        echo "</ul>";
        fclose($handle);
}else{
    echo "could not read from {$logfile}";
}

?>